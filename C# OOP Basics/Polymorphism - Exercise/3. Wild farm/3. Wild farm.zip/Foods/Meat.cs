﻿namespace _3.Wild_farm.Foods
{
    public class Meat : Food
    {
        public Meat(int quantity) : base(quantity)
        {
        }
    }
}
