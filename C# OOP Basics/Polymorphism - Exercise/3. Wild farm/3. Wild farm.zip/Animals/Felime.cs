﻿namespace _3.Wild_farm.Animals
{
    public abstract class Felime : Mammal
    {
        public Felime(string name, string type, double weight, string livingRegion) 
            : base(name, type, weight, livingRegion)
        {
        }
    }
}
