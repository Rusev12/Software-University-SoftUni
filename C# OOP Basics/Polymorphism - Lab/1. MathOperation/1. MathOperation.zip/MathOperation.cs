﻿namespace _1.MathOperation
{
    public class MathOperations
    {
        internal int Add(int first, int second)
        {
            return first + second;
        }

        internal double Add(double first, double second, double third)
        {
            return first + second + third;
        }

        internal decimal Add(decimal first, decimal second, decimal third)
        {
            return first + second + third;
        }
    }
}
