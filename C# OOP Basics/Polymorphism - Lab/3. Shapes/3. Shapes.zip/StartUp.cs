﻿namespace _3.Shapes
{
    public class StartUp
    {
        public static void Main()
        {

        }
    }
}
