﻿namespace _05.Mordor_s_Cruelty_Plan.Factories.Moods
{
    public class Sad : Mood
    {
        public Sad(int happinessPoints) : base(happinessPoints)
        {
        }
    }
}
