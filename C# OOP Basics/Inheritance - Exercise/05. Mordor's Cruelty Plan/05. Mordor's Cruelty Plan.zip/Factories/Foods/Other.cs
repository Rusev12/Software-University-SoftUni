﻿namespace _05.Mordor_s_Cruelty_Plan.Factories.Foods
{
    class Other : Food
    {
        private const int PointsOfHappiness = -1;

        public Other() : base(PointsOfHappiness)
        {
        }
    }
}
