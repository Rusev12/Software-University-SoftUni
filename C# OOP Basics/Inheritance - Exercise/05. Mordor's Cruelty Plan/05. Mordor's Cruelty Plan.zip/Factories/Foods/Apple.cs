﻿namespace _05.Mordor_s_Cruelty_Plan.Factories.Foods
{
    public class Apple : Food
    {
        private const int PointsOfHappiness = 1;

        public Apple() : base(PointsOfHappiness)
        {
        }
    }
}
