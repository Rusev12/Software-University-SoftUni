﻿namespace _05.Mordor_s_Cruelty_Plan.Factories.Foods
{
    public class Mushrooms : Food
    {
        private const int PointsOfHappiness = -10;

        public Mushrooms() : base(PointsOfHappiness)
        {
        }
    }
}
