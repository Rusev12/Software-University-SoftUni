﻿namespace _01.Single_Inheritance
{
    public class Puppy : Dog
    {
        public string Weep()
        {
            return "weeping...";
        }
    }
}
