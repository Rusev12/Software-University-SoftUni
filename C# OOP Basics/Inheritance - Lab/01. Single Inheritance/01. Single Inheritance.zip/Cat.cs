﻿namespace _01.Single_Inheritance
{
    public class Cat : Animal
    {
        public string Meow()
        {
            return "meowing...";
        }
    }
}
