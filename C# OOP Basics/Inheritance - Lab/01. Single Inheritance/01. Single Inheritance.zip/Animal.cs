﻿namespace _01.Single_Inheritance
{
    public class Animal
    {
        public string Eat()
        {
            return "eating...";
        }
    }
}