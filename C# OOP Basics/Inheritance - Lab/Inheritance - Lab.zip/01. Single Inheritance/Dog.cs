﻿namespace _01.Single_Inheritance
{
    public class Dog : Animal
    {
        public string Bark()
        {
            return "barking...";
        }
    }
}