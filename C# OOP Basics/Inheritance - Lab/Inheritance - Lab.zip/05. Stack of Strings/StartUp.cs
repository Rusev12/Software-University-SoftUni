﻿namespace _05.Stack_of_Strings
{
    using System;

    public class StartUp
    {
        public static void Main()
        {

        }
    }
}
